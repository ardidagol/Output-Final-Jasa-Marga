Title: Add a Google Map to a VB Application
Description: This project demonstrates a quick and easy way to add mapping to a windows desktop application (with an available internet connection) using Google Maps as the basis and source for the map. The demonstration application will map a point by either its physical address or its latitude and longitude. Building the application does not require any sort of agreement or licensing with Google; there is no required API to invoke and using this approach it really won&#8217;t take more than a few minutes to put a map into your Visual Basic 2005 built desktop application.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6282&lngWId=10

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
